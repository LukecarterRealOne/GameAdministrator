# Game Administrator (Fabric, Minecraft 26.1)

You are the **game administrator**. Press **G** to open the Admin Console and use nine abilities.
Press **V** to repeat the last one. Both keys can be changed under Controls -> Game Administrator.

| # | Ability | What it does | Cooldown | Screen VFX (no particles) |
|---|---------|--------------|----------|---------------------------|
| 1 | Smite | Lightning on every hostile mob within 28 blocks (or where you look) | 8s | white flash, jagged bolt, violet edge glow |
| 2 | Blink | Teleport to where you look, up to 40 blocks, stops before walls | 3s | cyan speed lines + tunnel vignette |
| 3 | Time Warp | Flip day / night | 5s | gold tint, expanding clock rings, spinning hands |
| 4 | Weather Control | Cycle clear -> rain -> thunder | 5s | cold wash, sweeping band, falling streaks |
| 5 | Full Restore | Full health, hunger, clears bad effects | 10s | green wave rising from the bottom, swelling cross |
| 6 | God Mode | 20s invulnerability + regen + absorption | 45s | pulsing gold frame with live countdown |
| 7 | Skyward | Launch into the sky, then glide down safely | 6s | upward white streaks + white-out |
| 8 | Freeze Field | Freeze + highlight mobs within 24 blocks for 10s | 20s | frosted corners, icy edges, crack lines |
| 9 | Purge | Delete hostile mobs within 48 blocks (bosses spared) | 30s | red flicker, scanline, glitch bars |

All VFX are drawn on the HUD with rectangles, gradients and outlines. There are no particles.

## Install
Minecraft **26.1.x**, **Fabric Loader 0.19.3+**, **Fabric API**, Java 25.
Put the jar in `mods/`. For multiplayer, install it on the server **and** every client.

Note: any player with the mod can use the abilities. Single player is where this is meant to be played.

## Build on GitHub
1. Make a new GitHub repo and upload everything in this folder (or upload the zip itself).
2. Open the **Actions** tab, wait for "Build mod" to finish.
3. Download the `gameadmin-26.1-fabric` artifact. The jar inside is the mod.

## Build locally
JDK 25 and Gradle 9.4 or newer: `gradle build`. The jar lands in `build/libs/`.
