package com.gameadmin.mod.client;

import com.gameadmin.mod.CastRequestPayload;
import com.gameadmin.mod.FeedbackPayload;
import com.gameadmin.mod.GameAdminMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/** Client entrypoint: keys, the VFX overlay and the feedback receiver. */
public class GameAdminClient implements ClientModInitializer {
    private static KeyMapping openKey;
    private static KeyMapping repeatKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(GameAdminMod.id("main"));

        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.gameadmin.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, category));
        repeatKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.gameadmin.repeat", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.consumeClick()) {
                if (client.player != null) {
                    client.setScreen(new AdminScreen());
                }
            }
            while (repeatKey.consumeClick()) {
                if (client.player != null && ClientState.lastCast >= 0) {
                    ClientPlayNetworking.send(new CastRequestPayload(ClientState.lastCast));
                }
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(FeedbackPayload.TYPE,
                (payload, context) -> ClientState.onFeedback(payload));

        // Screen VFX are drawn on the HUD, just before the chat layer.
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, GameAdminMod.id("vfx"), Vfx::extract);
    }
}
