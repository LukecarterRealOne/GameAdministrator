package com.gameadmin.mod;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

/** Client -> server: "please cast ability #n". */
public record CastRequestPayload(int ability) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<CastRequestPayload> TYPE =
            new CustomPacketPayload.Type<>(GameAdminMod.id("cast_request"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CastRequestPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.INT, CastRequestPayload::ability, CastRequestPayload::new);

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
