package com.gameadmin.mod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Server side brain: cooldowns + what every ability actually does.
 * Anything that is awkward to do through raw game code (weather, time, effects, lightning) is run as a vanilla
 * command with the server's own permissions, which keeps the mod small and stable across Minecraft versions.
 */
public final class AbilityManager {
    private AbilityManager() {}

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();
    private static boolean nextIsNight = true;
    private static int weatherStep = 0;

    public static void handleCast(ServerPlayer player, int id) {
        if (id < 0 || id >= Ability.ALL.length) return;
        Ability ability = Ability.ALL[id];

        long now = System.currentTimeMillis();
        long[] ready = READY_AT.computeIfAbsent(player.getUUID(), k -> new long[Ability.ALL.length]);
        if (now < ready[id]) {
            send(player, id, FeedbackPayload.COOLDOWN, (int) (ready[id] - now));
            return;
        }

        if (!(player.level() instanceof ServerLevel level)) return;
        MinecraftServer server = level.getServer();

        int affected = 0;
        try {
            affected = switch (ability) {
                case SMITE -> smite(player, level, server);
                case BLINK -> blink(player, level, server);
                case TIME_WARP -> timeWarp(server);
                case WEATHER -> weather(server);
                case RESTORE -> restore(player, server);
                case GOD_MODE -> godMode(player, server);
                case SKYWARD -> skyward(player, server);
                case FREEZE -> freeze(player, level, server);
                case PURGE -> purge(player, level);
            };
        } catch (Exception ex) {
            GameAdminMod.LOGGER.warn("Ability {} failed", ability, ex);
        }

        ready[id] = now + ability.cooldownMs;
        send(player, id, FeedbackPayload.CAST, affected);
    }

    private static void send(ServerPlayer player, int ability, int status, int value) {
        ServerPlayNetworking.send(player, new FeedbackPayload(ability, status, value));
    }

    // ------------------------------------------------------------------ abilities

    private static int smite(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        int strikes = 0;
        for (LivingEntity e : hostiles(player, level, 28.0)) {
            if (e.distanceTo(player) < 3.5f) continue; // never zap yourself
            if (strikes >= 14) break;
            runAt(server, e, "summon minecraft:lightning_bolt ~ ~ ~");
            strikes++;
        }
        if (strikes == 0) {
            double[] p = rayEnd(player, level, 48.0);
            double dx = p[0] - player.getX(), dz = p[2] - player.getZ();
            if (dx * dx + dz * dz > 16.0) {
                run(server, "summon minecraft:lightning_bolt " + xyz(p[0], p[1], p[2]));
                strikes = 1;
            }
        }
        return strikes;
    }

    private static int blink(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        double[] p = rayEnd(player, level, 40.0);
        run(server, "tp " + player.getUUID() + " " + xyz(p[0], p[1], p[2]));
        return 1;
    }

    private static int timeWarp(MinecraftServer server) {
        run(server, nextIsNight ? "time set night" : "time set day");
        nextIsNight = !nextIsNight;
        return 1;
    }

    private static int weather(MinecraftServer server) {
        String[] steps = {"clear", "rain", "thunder"};
        weatherStep = (weatherStep + 1) % steps.length;
        run(server, "weather " + steps[weatherStep]);
        return weatherStep;
    }

    private static int restore(ServerPlayer player, MinecraftServer server) {
        player.setHealth(player.getMaxHealth());
        String u = player.getUUID().toString();
        run(server, "effect give " + u + " minecraft:saturation 2 20 true");
        run(server, "effect give " + u + " minecraft:fire_resistance 5 0 true");
        for (String bad : new String[]{"poison", "wither", "hunger", "weakness", "slowness", "nausea",
                "blindness", "mining_fatigue", "darkness", "levitation"}) {
            run(server, "effect clear " + u + " minecraft:" + bad);
        }
        return 1;
    }

    private static int godMode(ServerPlayer player, MinecraftServer server) {
        String u = player.getUUID().toString();
        run(server, "effect give " + u + " minecraft:resistance 20 4 true");
        run(server, "effect give " + u + " minecraft:regeneration 20 2 true");
        run(server, "effect give " + u + " minecraft:absorption 20 4 true");
        run(server, "effect give " + u + " minecraft:fire_resistance 20 0 true");
        return 1;
    }

    private static int skyward(ServerPlayer player, MinecraftServer server) {
        String u = player.getUUID().toString();
        run(server, "effect give " + u + " minecraft:levitation 2 20 true");
        run(server, "effect give " + u + " minecraft:slow_falling 30 0 true");
        return 1;
    }

    private static int freeze(ServerPlayer player, ServerLevel level, MinecraftServer server) {
        int count = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(24.0))) {
            if (e == player || e instanceof Player) continue;
            runAs(server, e, "effect give @s minecraft:slowness 10 10 true");
            runAs(server, e, "effect give @s minecraft:weakness 10 3 true");
            runAs(server, e, "effect give @s minecraft:glowing 10 0 true");
            count++;
        }
        return count;
    }

    private static int purge(ServerPlayer player, ServerLevel level) {
        int count = 0;
        for (LivingEntity e : hostiles(player, level, 48.0)) {
            if (e.getType() == EntityType.ENDER_DRAGON || e.getType() == EntityType.WITHER) continue; // spare bosses
            e.discard();
            count++;
        }
        return count;
    }

    // ------------------------------------------------------------------ helpers

    /** Monsters near the player (never players, pets, villagers or animals). */
    private static List<LivingEntity> hostiles(ServerPlayer player, ServerLevel level, double radius) {
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(radius))) {
            if (e == player || e instanceof Player) continue;
            if (e.getType().getCategory() != MobCategory.MONSTER) continue;
            out.add(e);
        }
        return out;
    }

    /**
     * Marches along the player's look direction and returns {x, y(feet), z} of the last spot a player
     * could stand in before hitting something solid.
     */
    private static double[] rayEnd(ServerPlayer player, ServerLevel level, double maxDistance) {
        double yaw = Math.toRadians(player.getYRot());
        double pitch = Math.toRadians(player.getXRot());
        double dx = -Math.sin(yaw) * Math.cos(pitch);
        double dy = -Math.sin(pitch);
        double dz = Math.cos(yaw) * Math.cos(pitch);

        double ex = player.getX(), ey = player.getEyeY(), ez = player.getZ();
        double bx = player.getX(), by = player.getY(), bz = player.getZ();

        for (double s = 0.5; s <= maxDistance; s += 0.5) {
            double fx = ex + dx * s, fy = ey + dy * s, fz = ez + dz * s;
            double feetY = fy - 1.62;
            BlockPos feet = BlockPos.containing(fx, feetY, fz);
            BlockPos head = feet.above();
            if (blocked(level, feet) || blocked(level, head)) break;
            bx = fx;
            by = feetY;
            bz = fz;
        }
        return new double[]{bx, by, bz};
    }

    private static boolean blocked(ServerLevel level, BlockPos pos) {
        return !level.getBlockState(pos).getCollisionShape(level, pos).isEmpty();
    }

    private static String xyz(double x, double y, double z) {
        return String.format(Locale.ROOT, "%.2f %.2f %.2f", x, y, z);
    }

    /** Run a command as the server (full permissions, no chat spam). */
    private static void run(MinecraftServer server, String command) {
        server.getCommands().performPrefixedCommand(server.createCommandSourceStack().withSuppressedOutput(), command);
    }

    /** Run a command as an entity (@s = that entity), at that entity's position. */
    private static void runAs(MinecraftServer server, LivingEntity e, String command) {
        run(server, "execute as " + e.getUUID() + " run " + command);
    }

    private static void runAt(MinecraftServer server, LivingEntity e, String command) {
        run(server, "execute as " + e.getUUID() + " at @s run " + command);
    }
}
